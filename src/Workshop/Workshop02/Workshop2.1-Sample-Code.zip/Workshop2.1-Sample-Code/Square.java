// Square.java
// Class Square definition

public class Square extends Parallelogram
{
   // constructor
   public Square(double x1, double y1, double x2, double y2,
      double x3, double y3, double x4, double y4)
   {
      //
   }

   // return string representation of Square object including coordinates, height and area.
   @Override
   public String toString()
   {
      //add your code here
   }
} // end class Square


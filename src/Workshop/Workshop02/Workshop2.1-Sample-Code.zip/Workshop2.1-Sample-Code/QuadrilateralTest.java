// QuadrilateralTest.java
// Driver for Workshop 2

public class QuadrilateralTest
{
   public static void main(String[] args)
   {
      // NOTE: All coordinates are assumed to form the proper shapes
      // A quadrilateral is a four-sided polygon
      Quadrilateral quadrilateral =
         new Quadrilateral(1.1, 1.2, 6.6, 2.8, 6.2, 9.9, 2.2, 7.4);

      // Create an instance of parallelogram here


      // Create an instance of rectangle here


      // Create an instance of square here


	  // print the four created objects here
   }
} // end class QuadrilateralTest


// Rectangle.java
// Class Rectangle definition

public class Rectangle extends Parallelogram
{
   // constructor
   public Rectangle(double x1, double y1, double x2, double y2,
      double x3, double y3, double x4, double y4)
   {
      //add your code here
   }

   // return string representation of Rectangle object including coordinates, width, height and area.
   @Override
   public String toString()
   {
       // add your code here
   }
} // end class Rectangle

